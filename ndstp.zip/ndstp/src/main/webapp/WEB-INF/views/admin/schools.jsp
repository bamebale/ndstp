<%@ include file="/WEB-INF/views/layout/header.jspf" %>
<h1>Driving schools</h1>
<c:choose>
  <c:when test="${empty schools}"><p class="muted">No schools have registered yet.</p></c:when>
  <c:otherwise>
    <div class="scroll">
    <table class="table">
      <thead><tr><th>School</th><th>Town</th><th>Fee</th><th>Status</th><th></th></tr></thead>
      <tbody>
        <c:forEach var="s" items="${schools}">
          <tr>
            <td><c:out value="${s.name}"/></td>
            <td><c:out value="${s.location}"/></td>
            <td>P<fmt:formatNumber value="${s.feePerLesson}" minFractionDigits="2" maxFractionDigits="2"/></td>
            <td><span class="badge ${s.accredited ? 'passed' : 'confirmed'}">${s.accredited ? 'Accredited' : 'Pending'}</span></td>
            <td class="right">
              <form method="post" action="${ctx}/admin/schools" class="inline">
                <input type="hidden" name="_csrf" value="${csrfToken}">
                <input type="hidden" name="schoolId" value="${s.id}">
                <input type="hidden" name="accredited" value="${!s.accredited}">
                <button class="btn small ${s.accredited ? 'danger' : ''}" type="submit">${s.accredited ? 'Revoke' : 'Accredit'}</button>
              </form>
            </td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
    </div>
  </c:otherwise>
</c:choose>
<%@ include file="/WEB-INF/views/layout/footer.jspf" %>
