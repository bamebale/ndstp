<%@ include file="/WEB-INF/views/layout/header.jspf" %>
<h1>Dashboard</h1>
<section class="facts">
  <div><strong>${stats.upcomingSlots}</strong> upcoming slots</div>
  <div><strong>${stats.confirmed}</strong> confirmed bookings</div>
  <div><strong>${stats.passed}</strong> tests passed</div>
  <div><strong>${stats.failed}</strong> tests failed</div>
  <div><strong>${stats.learners}</strong> learners</div>
  <div><strong>${stats.schools}</strong> accredited schools</div>
</section>
<c:if test="${stats.pendingSchools > 0}">
  <div class="alert warn">${stats.pendingSchools} school(s) are waiting for accreditation. <a href="${ctx}/admin/schools">Review them</a>.</div>
</c:if>
<%@ include file="/WEB-INF/views/layout/footer.jspf" %>
