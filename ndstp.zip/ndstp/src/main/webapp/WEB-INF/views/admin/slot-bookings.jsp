<%@ include file="/WEB-INF/views/layout/header.jspf" %>
<p><a href="${ctx}/admin/slots">Back to all slots</a></p>
<h1>${slot.testType.label}</h1>
<p class="muted">
  <fmt:formatDate value="${slot.slotDateTime}" pattern="EEEE d MMMM yyyy, HH:mm"/> at <c:out value="${slot.location}"/>
  &middot; ${slot.booked} of ${slot.capacity} places booked
</p>

<c:choose>
  <c:when test="${empty bookings}"><p class="muted">Nobody has booked this slot yet.</p></c:when>
  <c:otherwise>
    <div class="scroll">
    <table class="table">
      <thead><tr><th>Learner</th><th>Email</th><th>Status</th><th>Record result</th></tr></thead>
      <tbody>
        <c:forEach var="b" items="${bookings}">
          <tr>
            <td><c:out value="${b.learnerName}"/></td>
            <td><c:out value="${b.learnerEmail}"/></td>
            <td><span class="badge ${fn:toLowerCase(b.status)}">${b.status}</span></td>
            <td>
              <c:if test="${b.status eq 'CONFIRMED'}">
                <c:forEach var="r" items="${['PASSED','FAILED']}">
                  <form method="post" action="${ctx}/admin/slots" class="inline">
                    <input type="hidden" name="_csrf" value="${csrfToken}">
                    <input type="hidden" name="action" value="result">
                    <input type="hidden" name="bookingId" value="${b.id}">
                    <input type="hidden" name="slotId" value="${slot.id}">
                    <input type="hidden" name="result" value="${r}">
                    <button class="btn small ${r eq 'FAILED' ? 'danger' : ''}" type="submit">${r eq 'PASSED' ? 'Passed' : 'Failed'}</button>
                  </form>
                </c:forEach>
              </c:if>
            </td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
    </div>
  </c:otherwise>
</c:choose>
<%@ include file="/WEB-INF/views/layout/footer.jspf" %>
