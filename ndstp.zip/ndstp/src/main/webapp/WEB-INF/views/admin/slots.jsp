<%@ include file="/WEB-INF/views/layout/header.jspf" %>
<h1>Test slots</h1>

<h2>Publish a slot</h2>
<form method="post" action="${ctx}/admin/slots" class="filters">
  <input type="hidden" name="_csrf" value="${csrfToken}">
  <input type="hidden" name="action" value="create">
  <label>Test
    <select name="type">
      <c:forEach var="t" items="${types}"><option value="${t}">${t.label}</option></c:forEach>
    </select>
  </label>
  <label>Date and time
    <input type="datetime-local" name="dateTime" required>
  </label>
  <label>Test centre
    <input name="location" required maxlength="100" placeholder="Gaborone DRTS">
  </label>
  <label>Capacity
    <input type="number" name="capacity" min="1" max="500" value="20" required>
  </label>
  <button class="btn" type="submit">Publish slot</button>
</form>

<h2>All slots</h2>
<c:choose>
  <c:when test="${empty slots}"><p class="muted">No slots yet. Publish the first one above.</p></c:when>
  <c:otherwise>
    <div class="scroll">
    <table class="table">
      <thead><tr><th>Test</th><th>Date and time</th><th>Centre</th><th>Booked</th><th></th></tr></thead>
      <tbody>
        <c:forEach var="s" items="${slots}">
          <tr class="${s.past ? 'past' : ''}">
            <td>${s.testType.label}</td>
            <td><fmt:formatDate value="${s.slotDateTime}" pattern="EEE d MMM yyyy, HH:mm"/></td>
            <td><c:out value="${s.location}"/></td>
            <td>${s.booked} of ${s.capacity}</td>
            <td class="right"><a href="${ctx}/admin/slots?id=${s.id}">View bookings</a></td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
    </div>
  </c:otherwise>
</c:choose>
<%@ include file="/WEB-INF/views/layout/footer.jspf" %>
