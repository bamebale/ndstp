<%@ include file="/WEB-INF/views/layout/header.jspf" %>
<h1>Accredited driving schools</h1>
<form method="get" action="${ctx}/schools" class="filters">
  <label>Search
    <input name="q" value="${fn:escapeXml(param.q)}" placeholder="School name or keyword">
  </label>
  <label>Town
    <select name="location">
      <option value="">All towns</option>
      <c:forEach var="l" items="${locations}">
        <option value="${fn:escapeXml(l)}" ${param.location eq l ? 'selected' : ''}><c:out value="${l}"/></option>
      </c:forEach>
    </select>
  </label>
  <label>Max fee per lesson (P)
    <input name="maxFee" type="number" min="0" step="10" value="${fn:escapeXml(param.maxFee)}">
  </label>
  <button class="btn" type="submit">Search</button>
</form>

<c:choose>
  <c:when test="${empty schools}">
    <p class="muted">No schools match your search. Clear a filter to see more.</p>
  </c:when>
  <c:otherwise>
    <div class="list">
      <c:forEach var="s" items="${schools}">
        <article class="item">
          <div>
            <h2><a href="${ctx}/schools/view?id=${s.id}"><c:out value="${s.name}"/></a></h2>
            <p class="muted"><c:out value="${s.location}"/></p>
            <p><c:out value="${fn:substring(s.description, 0, 160)}"/></p>
          </div>
          <div class="price">
            <strong>P<fmt:formatNumber value="${s.feePerLesson}" minFractionDigits="2" maxFractionDigits="2"/></strong>
            <span class="muted">per lesson</span>
          </div>
        </article>
      </c:forEach>
    </div>
  </c:otherwise>
</c:choose>
<%@ include file="/WEB-INF/views/layout/footer.jspf" %>
