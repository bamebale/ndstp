<%@ include file="/WEB-INF/views/layout/header.jspf" %>
<p><a href="${ctx}/schools">Back to all schools</a></p>
<h1><c:out value="${school.name}"/></h1>
<p><span class="badge passed">Accredited</span> <span class="muted"><c:out value="${school.location}"/></span></p>
<p class="prose"><c:out value="${school.description}"/></p>
<dl class="details">
  <dt>Fee per lesson</dt>
  <dd>P<fmt:formatNumber value="${school.feePerLesson}" minFractionDigits="2" maxFractionDigits="2"/></dd>
  <c:if test="${not empty school.phone}"><dt>Phone</dt><dd><c:out value="${school.phone}"/></dd></c:if>
  <c:if test="${not empty school.email}"><dt>Email</dt><dd><a href="mailto:${fn:escapeXml(school.email)}"><c:out value="${school.email}"/></a></dd></c:if>
</dl>
<%@ include file="/WEB-INF/views/layout/footer.jspf" %>
