<%@ include file="/WEB-INF/views/layout/header.jspf" %>
<c:set var="posted" value="${not empty paramValues.name}"/>
<h1>My driving school</h1>

<c:choose>
  <c:when test="${empty school}"><div class="alert warn">You have not created your school profile yet. Fill in the form to get started.</div></c:when>
  <c:when test="${school.accredited}"><div class="alert success">Your school is accredited and listed in the public directory.</div></c:when>
  <c:otherwise><div class="alert warn">Your profile is saved and waiting for DRTS accreditation. It will appear in the directory once approved.</div></c:otherwise>
</c:choose>

<c:if test="${not empty errors}">
  <div class="alert error"><ul class="plain"><c:forEach var="e" items="${errors}"><li><c:out value="${e}"/></li></c:forEach></ul></div>
</c:if>

<form method="post" action="${ctx}/school/profile" class="form">
  <input type="hidden" name="_csrf" value="${csrfToken}">
  <label>School name
    <input name="name" required maxlength="120" value="${fn:escapeXml(posted ? param.name : school.name)}">
  </label>
  <label>Town or city
    <input name="location" required maxlength="100" value="${fn:escapeXml(posted ? param.location : school.location)}">
  </label>
  <label>Fee per lesson (P)
    <input name="fee" type="number" min="0" step="0.01" required value="${fn:escapeXml(posted ? param.fee : school.feePerLesson)}">
  </label>
  <label>Contact phone
    <input name="phone" maxlength="15" value="${fn:escapeXml(posted ? param.phone : school.phone)}">
  </label>
  <label>Contact email
    <input type="email" name="email" maxlength="120" value="${fn:escapeXml(posted ? param.email : school.email)}">
  </label>
  <label>Description
    <textarea name="description" rows="6" maxlength="2000"><c:out value="${posted ? param.description : school.description}"/></textarea>
  </label>
  <button class="btn" type="submit">Save school profile</button>
</form>
<%@ include file="/WEB-INF/views/layout/footer.jspf" %>
