<%@ include file="/WEB-INF/views/layout/header.jspf" %>
<div class="narrow">
  <h1>Create an account</h1>
  <c:if test="${not empty errors}">
    <div class="alert error">
      <ul class="plain">
        <c:forEach var="e" items="${errors}"><li><c:out value="${e}"/></li></c:forEach>
      </ul>
    </div>
  </c:if>
  <form method="post" action="${ctx}/register" class="form">
    <input type="hidden" name="_csrf" value="${csrfToken}">
    <label>I am a
      <select name="role">
        <option value="LEARNER" ${param.role ne 'SCHOOL_MANAGER' ? 'selected' : ''}>Learner driver</option>
        <option value="SCHOOL_MANAGER" ${param.role eq 'SCHOOL_MANAGER' ? 'selected' : ''}>Driving school manager</option>
      </select>
    </label>
    <label>Full name
      <input name="fullName" value="${fn:escapeXml(param.fullName)}" required maxlength="100">
    </label>
    <label>Email
      <input type="email" name="email" value="${fn:escapeXml(param.email)}" required maxlength="120">
    </label>
    <label>Omang number <span class="muted">(learners only, 9 digits)</span>
      <input name="idNumber" value="${fn:escapeXml(param.idNumber)}" inputmode="numeric" maxlength="9">
    </label>
    <label>Phone <span class="muted">(optional)</span>
      <input name="phone" value="${fn:escapeXml(param.phone)}" maxlength="15">
    </label>
    <label>Password
      <input type="password" name="password" required minlength="8">
    </label>
    <label>Confirm password
      <input type="password" name="confirm" required minlength="8">
    </label>
    <button class="btn" type="submit">Create account</button>
  </form>
  <p class="muted">Already registered? <a href="${ctx}/login">Log in</a>.</p>
</div>
<%@ include file="/WEB-INF/views/layout/footer.jspf" %>
