<%@ page isErrorPage="true" %>
<%@ include file="/WEB-INF/views/layout/header.jspf" %>
<c:set var="code" value="${requestScope['jakarta.servlet.error.status_code']}"/>
<div class="narrow">
  <h1>
    <c:choose>
      <c:when test="${code == 403}">You can't open this page</c:when>
      <c:when test="${code == 404}">Page not found</c:when>
      <c:otherwise>Something went wrong</c:otherwise>
    </c:choose>
  </h1>
  <p>
    <c:choose>
      <c:when test="${code == 403}">Your account doesn't have access to this page, or your form expired. Go back and try again.</c:when>
      <c:when test="${code == 404}">Check the address, or start from the home page.</c:when>
      <c:otherwise>We could not complete your request. Try again in a moment.</c:otherwise>
    </c:choose>
  </p>
  <a class="btn" href="${ctx}/home">Go to home</a>
</div>
<%@ include file="/WEB-INF/views/layout/footer.jspf" %>
