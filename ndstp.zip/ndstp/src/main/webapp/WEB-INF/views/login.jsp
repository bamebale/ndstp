<%@ include file="/WEB-INF/views/layout/header.jspf" %>
<div class="narrow">
  <h1>Log in</h1>
  <c:if test="${not empty error}"><div class="alert error"><c:out value="${error}"/></div></c:if>
  <form method="post" action="${ctx}/login" class="form">
    <input type="hidden" name="_csrf" value="${csrfToken}">
    <label>Email
      <input type="email" name="email" value="${fn:escapeXml(param.email)}" required autofocus>
    </label>
    <label>Password
      <input type="password" name="password" required>
    </label>
    <button class="btn" type="submit">Log in</button>
  </form>
  <p class="muted">New here? <a href="${ctx}/register">Create an account</a>.</p>
</div>
<%@ include file="/WEB-INF/views/layout/footer.jspf" %>
