<%@ include file="/WEB-INF/views/layout/header.jspf" %>
<h1>Book a test</h1>
<div class="tabs" role="tablist">
  <c:forEach var="t" items="${types}">
    <a class="${t eq type ? 'active' : ''}" href="${ctx}/learner/slots?type=${t}">${t.label}</a>
  </c:forEach>
</div>

<c:if test="${not empty blockedReason}">
  <div class="alert warn"><c:out value="${blockedReason}"/></div>
</c:if>

<c:choose>
  <c:when test="${empty slots}">
    <p class="muted">No upcoming ${fn:toLowerCase(type.label)} slots are published yet. Check back soon.</p>
  </c:when>
  <c:otherwise>
    <div class="scroll">
    <table class="table">
      <thead><tr><th>Date and time</th><th>Test centre</th><th>Places left</th><th></th></tr></thead>
      <tbody>
        <c:forEach var="s" items="${slots}">
          <tr>
            <td><fmt:formatDate value="${s.slotDateTime}" pattern="EEE d MMM yyyy, HH:mm"/></td>
            <td><c:out value="${s.location}"/></td>
            <td>${s.available} of ${s.capacity}</td>
            <td class="right">
              <c:choose>
                <c:when test="${s.full}"><span class="badge off">Full</span></c:when>
                <c:when test="${not empty blockedReason}"><span class="badge off">Unavailable</span></c:when>
                <c:otherwise>
                  <form method="post" action="${ctx}/learner/slots" class="inline">
                    <input type="hidden" name="_csrf" value="${csrfToken}">
                    <input type="hidden" name="slotId" value="${s.id}">
                    <input type="hidden" name="type" value="${type}">
                    <button class="btn small" type="submit">Book this slot</button>
                  </form>
                </c:otherwise>
              </c:choose>
            </td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
    </div>
  </c:otherwise>
</c:choose>
<%@ include file="/WEB-INF/views/layout/footer.jspf" %>
