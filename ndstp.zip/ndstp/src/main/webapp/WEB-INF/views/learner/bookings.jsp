<%@ include file="/WEB-INF/views/layout/header.jspf" %>
<h1>My bookings</h1>
<c:choose>
  <c:when test="${empty bookings}">
    <p>You have no bookings yet. <a href="${ctx}/learner/slots">Book your theory test</a> to start.</p>
  </c:when>
  <c:otherwise>
    <div class="scroll">
    <table class="table">
      <thead><tr><th>Test</th><th>Date and time</th><th>Test centre</th><th>Status</th><th></th></tr></thead>
      <tbody>
        <c:forEach var="b" items="${bookings}">
          <tr>
            <td>${b.testType.label}</td>
            <td><fmt:formatDate value="${b.slotDateTime}" pattern="EEE d MMM yyyy, HH:mm"/></td>
            <td><c:out value="${b.location}"/></td>
            <td><span class="badge ${fn:toLowerCase(b.status)}">${b.status}</span></td>
            <td class="right">
              <c:if test="${b.cancellable}">
                <form method="post" action="${ctx}/learner/bookings" class="inline"
                      onsubmit="return confirm('Cancel this booking?');">
                  <input type="hidden" name="_csrf" value="${csrfToken}">
                  <input type="hidden" name="bookingId" value="${b.id}">
                  <button class="btn small danger" type="submit">Cancel</button>
                </form>
              </c:if>
            </td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
    </div>
    <p class="muted">Bookings can be cancelled up to 24 hours before the test.</p>
  </c:otherwise>
</c:choose>
<%@ include file="/WEB-INF/views/layout/footer.jspf" %>
