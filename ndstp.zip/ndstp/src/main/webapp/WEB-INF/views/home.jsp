<%@ include file="/WEB-INF/views/layout/header.jspf" %>
<section class="hero">
  <h1>Book your licence tests online. No queue.</h1>
  <p>Reserve your theory, yard and road test, then find an accredited driving school near you.</p>
  <div class="actions">
    <a class="btn" href="${ctx}/learner/slots">Book a test</a>
    <a class="btn secondary" href="${ctx}/schools">Find a driving school</a>
  </div>
</section>

<section class="route" aria-label="The three licence tests">
  <div class="stop"><h3>Theory test</h3><p>Pass this first. Book any open slot at your nearest centre.</p></div>
  <div class="stop"><h3>Yard test</h3><p>Unlocked once your theory result is recorded as passed.</p></div>
  <div class="stop"><h3>Road test</h3><p>Unlocked once you pass the yard test.</p></div>
</section>

<section class="facts">
  <div><strong>${stats.upcomingSlots}</strong> upcoming test slots</div>
  <div><strong>${stats.schools}</strong> accredited driving schools</div>
  <div><strong>${stats.learners}</strong> registered learners</div>
</section>
<%@ include file="/WEB-INF/views/layout/footer.jspf" %>
