package bw.ndstp.controller;

import bw.ndstp.model.User;
import bw.ndstp.service.BookingException;
import bw.ndstp.service.BookingService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** Learner: list own bookings and cancel. */
@WebServlet("/learner/bookings")
public class MyBookingsServlet extends BaseServlet {
    private final BookingService bookingService = new BookingService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setAttribute("bookings", bookingService.listByLearner(currentUser(req).getId()));
        forward(req, res, "learner/bookings");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User user = currentUser(req);
        try {
            bookingService.cancel(user.getId(), intParam(req, "bookingId", -1));
            flash(req, "success", "Booking cancelled.");
        } catch (BookingException e) {
            flash(req, "error", e.getMessage());
        }
        redirect(req, res, "/learner/bookings");
    }
}
