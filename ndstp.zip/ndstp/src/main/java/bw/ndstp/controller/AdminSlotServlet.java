package bw.ndstp.controller;

import bw.ndstp.model.BookingStatus;
import bw.ndstp.model.TestSlot;
import bw.ndstp.model.TestType;
import bw.ndstp.service.BookingException;
import bw.ndstp.service.BookingService;
import bw.ndstp.service.SlotService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/** Admin: publish slots, view who booked, record pass/fail. */
@WebServlet("/admin/slots")
public class AdminSlotServlet extends BaseServlet {
    private final SlotService slotService = new SlotService();
    private final BookingService bookingService = new BookingService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        if (req.getParameter("id") != null) {                       // bookings of one slot
            int id = intParam(req, "id", -1);
            TestSlot slot = slotService.find(id);
            if (slot == null) { redirect(req, res, "/admin/slots"); return; }
            req.setAttribute("slot", slot);
            req.setAttribute("bookings", bookingService.listBySlot(id));
            forward(req, res, "admin/slot-bookings");
            return;
        }
        req.setAttribute("slots", slotService.listAll());
        req.setAttribute("types", TestType.values());
        forward(req, res, "admin/slots");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String action = req.getParameter("action");
        if ("result".equals(action)) {
            int slotId = intParam(req, "slotId", -1);
            try {
                BookingStatus result = BookingStatus.valueOf(req.getParameter("result"));
                bookingService.recordResult(intParam(req, "bookingId", -1), result);
                flash(req, "success", "Result recorded.");
            } catch (BookingException e) {
                flash(req, "error", e.getMessage());
            } catch (IllegalArgumentException | NullPointerException e) {
                flash(req, "error", "Invalid result.");
            }
            redirect(req, res, "/admin/slots?id=" + slotId);
            return;
        }
        List<String> errors = slotService.create(req.getParameter("type"), req.getParameter("dateTime"),
                req.getParameter("location"), req.getParameter("capacity"));
        if (errors.isEmpty()) flash(req, "success", "Slot published.");
        else flash(req, "error", String.join(" ", errors));
        redirect(req, res, "/admin/slots");
    }
}
