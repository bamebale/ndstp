package bw.ndstp.controller;

import bw.ndstp.service.AuthService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/register")
public class RegisterServlet extends BaseServlet {
    private final AuthService authService = new AuthService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        forward(req, res, "register");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        List<String> errors = authService.register(
                req.getParameter("fullName"), req.getParameter("email"),
                req.getParameter("password"), req.getParameter("confirm"),
                req.getParameter("idNumber"), req.getParameter("phone"), req.getParameter("role"));
        if (!errors.isEmpty()) {
            req.setAttribute("errors", errors);
            forward(req, res, "register");
            return;
        }
        flash(req, "success", "Account created. Log in to continue.");
        redirect(req, res, "/login");
    }
}
