package bw.ndstp.controller;

import bw.ndstp.model.TestType;
import bw.ndstp.model.User;
import bw.ndstp.service.BookingException;
import bw.ndstp.service.BookingService;
import bw.ndstp.service.SlotService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** Learner: browse slots per test type and book one. */
@WebServlet("/learner/slots")
public class BookingServlet extends BaseServlet {
    private final SlotService slotService = new SlotService();
    private final BookingService bookingService = new BookingService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        User user = currentUser(req);
        TestType type = TestType.parse(req.getParameter("type"));
        req.setAttribute("types", TestType.values());
        req.setAttribute("type", type);
        req.setAttribute("blockedReason", bookingService.blockedReason(user.getId(), type));
        req.setAttribute("slots", slotService.upcoming(type));
        forward(req, res, "learner/slots");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User user = currentUser(req);
        String type = TestType.parse(req.getParameter("type")).name();
        try {
            bookingService.book(user.getId(), intParam(req, "slotId", -1));
            flash(req, "success", "Booking confirmed. See you at the test centre.");
            redirect(req, res, "/learner/bookings");
        } catch (BookingException e) {
            flash(req, "error", e.getMessage());
            redirect(req, res, "/learner/slots?type=" + type);
        }
    }
}
