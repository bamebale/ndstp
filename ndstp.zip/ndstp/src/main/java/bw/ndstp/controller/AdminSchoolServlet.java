package bw.ndstp.controller;

import bw.ndstp.service.SchoolService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** Admin: accredit or revoke driving schools. */
@WebServlet("/admin/schools")
public class AdminSchoolServlet extends BaseServlet {
    private final SchoolService schoolService = new SchoolService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setAttribute("schools", schoolService.listAll());
        forward(req, res, "admin/schools");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        boolean accredit = "true".equals(req.getParameter("accredited"));
        schoolService.setAccredited(intParam(req, "schoolId", -1), accredit);
        flash(req, "success", accredit ? "School accredited and now listed publicly." : "Accreditation revoked.");
        redirect(req, res, "/admin/schools");
    }
}
