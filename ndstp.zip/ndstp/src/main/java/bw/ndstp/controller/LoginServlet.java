package bw.ndstp.controller;

import bw.ndstp.model.User;
import bw.ndstp.service.AuthService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends BaseServlet {
    private final AuthService authService = new AuthService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        User user = currentUser(req);
        if (user != null) { redirect(req, res, user.getRole().getHomePath()); return; }
        forward(req, res, "login");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        User user = authService.login(req.getParameter("email"), req.getParameter("password"));
        if (user == null) {
            req.setAttribute("error", "Incorrect email or password.");
            forward(req, res, "login");
            return;
        }
        req.changeSessionId();                       // prevent session fixation
        req.getSession().setAttribute("user", user);
        redirect(req, res, user.getRole().getHomePath());
    }
}
