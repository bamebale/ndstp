package bw.ndstp.controller;

import bw.ndstp.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Map;

/** Shared helpers for all controllers. */
public abstract class BaseServlet extends HttpServlet {

    protected User currentUser(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        return s == null ? null : (User) s.getAttribute("user");
    }

    /** One-shot message shown on the next page (read and removed by header.jspf). */
    protected void flash(HttpServletRequest req, String type, String message) {
        req.getSession().setAttribute("flash", Map.of("type", type, "message", message));
    }

    protected void forward(HttpServletRequest req, HttpServletResponse res, String view)
            throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/" + view + ".jsp").forward(req, res);
    }

    protected void redirect(HttpServletRequest req, HttpServletResponse res, String path) throws IOException {
        res.sendRedirect(req.getContextPath() + path);
    }

    protected int intParam(HttpServletRequest req, String name, int fallback) {
        try { return Integer.parseInt(req.getParameter(name).trim()); }
        catch (Exception e) { return fallback; }
    }
}
