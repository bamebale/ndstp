package bw.ndstp.controller;

import bw.ndstp.model.User;
import bw.ndstp.service.SchoolService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/** School manager: edit own school profile (always scoped to the logged-in manager). */
@WebServlet("/school/profile")
public class SchoolManagerServlet extends BaseServlet {
    private final SchoolService schoolService = new SchoolService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setAttribute("school", schoolService.getByManager(currentUser(req).getId()));
        forward(req, res, "school/profile");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        User user = currentUser(req);
        List<String> errors = schoolService.save(user.getId(),
                req.getParameter("name"), req.getParameter("description"), req.getParameter("location"),
                req.getParameter("phone"), req.getParameter("email"), req.getParameter("fee"));
        if (!errors.isEmpty()) {
            req.setAttribute("errors", errors);
            req.setAttribute("school", schoolService.getByManager(user.getId()));
            forward(req, res, "school/profile");
            return;
        }
        flash(req, "success", "School profile saved.");
        redirect(req, res, "/school/profile");
    }
}
