package bw.ndstp.controller;

import bw.ndstp.model.DrivingSchool;
import bw.ndstp.service.SchoolService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** Public marketplace: search accredited schools, and view one school. */
@WebServlet(urlPatterns = {"/schools", "/schools/view"})
public class SchoolDirectoryServlet extends BaseServlet {
    private final SchoolService schoolService = new SchoolService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        if (req.getRequestURI().endsWith("/schools/view")) {
            DrivingSchool school = schoolService.getPublic(intParam(req, "id", -1));
            if (school == null) { res.sendError(HttpServletResponse.SC_NOT_FOUND); return; }
            req.setAttribute("school", school);
            forward(req, res, "schools/detail");
            return;
        }
        req.setAttribute("schools", schoolService.search(
                req.getParameter("q"), req.getParameter("location"), req.getParameter("maxFee")));
        req.setAttribute("locations", schoolService.locations());
        forward(req, res, "schools/list");
    }
}
