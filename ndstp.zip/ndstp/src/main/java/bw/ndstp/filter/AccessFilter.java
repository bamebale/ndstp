package bw.ndstp.filter;

import bw.ndstp.model.Role;
import bw.ndstp.model.User;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/** Role-Based Access Control: /learner/* , /school/* and /admin/* each require their own role. */
@WebFilter(urlPatterns = {"/learner/*", "/school/*", "/admin/*"})
public class AccessFilter implements Filter {
    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        String path = request.getRequestURI().substring(request.getContextPath().length());
        Role required = path.startsWith("/admin") ? Role.ADMIN
                : path.startsWith("/school/") ? Role.SCHOOL_MANAGER
                : Role.LEARNER;

        HttpSession session = request.getSession(false);
        User user = session == null ? null : (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        if (user.getRole() != required) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "You do not have access to this page.");
            return;
        }
        chain.doFilter(req, res);
    }
}
