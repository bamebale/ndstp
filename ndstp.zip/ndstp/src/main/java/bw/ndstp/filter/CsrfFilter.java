package bw.ndstp.filter;

import bw.ndstp.util.Csrf;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** Sets UTF-8, exposes ${csrfToken} to every page and rejects POSTs without a valid token. */
@WebFilter("/*")
public class CsrfFilter implements Filter {
    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        request.setCharacterEncoding("UTF-8");

        String path = request.getRequestURI().substring(request.getContextPath().length());
        if (path.startsWith("/css/") || path.startsWith("/js/") || path.startsWith("/img/")) {
            chain.doFilter(req, res);
            return;
        }

        request.setAttribute(Csrf.ATTRIBUTE, Csrf.token(request.getSession()));

        if ("POST".equalsIgnoreCase(request.getMethod())
                && !Csrf.isValid(request.getSession(false), request.getParameter(Csrf.PARAMETER))) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Your session expired or the form is invalid. Reload the page and try again.");
            return;
        }
        chain.doFilter(req, res);
    }
}
