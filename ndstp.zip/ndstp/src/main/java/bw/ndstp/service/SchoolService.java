package bw.ndstp.service;

import bw.ndstp.dao.DataAccessException;
import bw.ndstp.dao.SchoolDao;
import bw.ndstp.model.DrivingSchool;
import bw.ndstp.util.DbPool;
import bw.ndstp.util.Validator;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SchoolService {
    private final SchoolDao schoolDao = new SchoolDao();

    public DrivingSchool getByManager(int managerId) {
        try (Connection c = DbPool.get()) {
            return schoolDao.findByManager(c, managerId);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    /** Public view: accredited schools only. */
    public DrivingSchool getPublic(int id) {
        try (Connection c = DbPool.get()) {
            DrivingSchool s = schoolDao.findById(c, id);
            return s != null && s.isAccredited() ? s : null;
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public List<DrivingSchool> search(String text, String location, String maxFee) {
        BigDecimal fee = null;
        try {
            if (!Validator.blank(maxFee)) fee = new BigDecimal(maxFee.trim());
        } catch (NumberFormatException ignored) { /* ignore a bad filter value */ }
        try (Connection c = DbPool.get()) {
            return schoolDao.search(c, text, location, fee, true);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public List<String> locations() {
        try (Connection c = DbPool.get()) {
            return schoolDao.accreditedLocations(c);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public List<DrivingSchool> listAll() {
        try (Connection c = DbPool.get()) {
            return schoolDao.findAll(c);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public void setAccredited(int schoolId, boolean accredited) {
        try (Connection c = DbPool.get()) {
            schoolDao.setAccredited(c, schoolId, accredited);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    /** Creates or updates the manager's own school profile. Returns validation errors. */
    public List<String> save(int managerId, String name, String description, String location,
                             String phone, String email, String fee) {
        List<String> errors = new ArrayList<>();
        name = Validator.trim(name);
        description = Validator.trim(description);
        location = Validator.trim(location);
        phone = Validator.trim(phone);
        email = Validator.trim(email);

        if (name.length() < 3 || name.length() > 120) errors.add("School name must be 3-120 characters.");
        if (location.isEmpty() || location.length() > 100) errors.add("Enter the town or city where the school operates.");
        if (description.length() > 2000) errors.add("Description is limited to 2000 characters.");
        if (!phone.isEmpty() && !Validator.phone(phone)) errors.add("Enter a valid phone number.");
        if (!email.isEmpty() && !Validator.email(email)) errors.add("Enter a valid contact email.");
        BigDecimal feeValue = BigDecimal.ZERO;
        try {
            feeValue = new BigDecimal(Validator.trim(fee));
            if (feeValue.signum() < 0 || feeValue.compareTo(new BigDecimal("100000")) > 0) {
                errors.add("Fee per lesson must be between 0 and 100000.");
            }
        } catch (NumberFormatException e) { errors.add("Fee per lesson must be a number."); }
        if (!errors.isEmpty()) return errors;

        DrivingSchool s = new DrivingSchool();
        s.setManagerId(managerId);
        s.setName(name);
        s.setDescription(description);
        s.setLocation(location);
        s.setPhone(phone.isEmpty() ? null : phone);
        s.setEmail(email.isEmpty() ? null : email);
        s.setFeePerLesson(feeValue);
        try (Connection c = DbPool.get()) {
            if (schoolDao.findByManager(c, managerId) == null) schoolDao.insert(c, s);
            else schoolDao.update(c, s);
        } catch (SQLException e) { throw new DataAccessException(e); }
        return errors;
    }
}
