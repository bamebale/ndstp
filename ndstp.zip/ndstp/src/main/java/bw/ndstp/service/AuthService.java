package bw.ndstp.service;

import bw.ndstp.dao.DataAccessException;
import bw.ndstp.dao.UserDao;
import bw.ndstp.model.Role;
import bw.ndstp.model.User;
import bw.ndstp.util.DbPool;
import bw.ndstp.util.PasswordUtil;
import bw.ndstp.util.Validator;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AuthService {
    private final UserDao userDao = new UserDao();

    /** Returns the user (without password hash) or null when credentials are wrong. */
    public User login(String email, String password) {
        if (!Validator.email(email) || Validator.blank(password)) return null;
        try (Connection c = DbPool.get()) {
            User u = userDao.findByEmail(c, email.trim());
            if (u == null || !PasswordUtil.verify(password, u.getPasswordHash())) return null;
            u.setPasswordHash(null);
            return u;
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    /** Validates and registers a LEARNER or SCHOOL_MANAGER. Returns a list of errors (empty on success). */
    public List<String> register(String fullName, String email, String password, String confirm,
                                 String idNumber, String phone, String roleParam) {
        List<String> errors = new ArrayList<>();
        Role role = "SCHOOL_MANAGER".equals(roleParam) ? Role.SCHOOL_MANAGER : Role.LEARNER; // never ADMIN
        fullName = Validator.trim(fullName);
        email = Validator.trim(email).toLowerCase();
        idNumber = Validator.trim(idNumber);
        phone = Validator.trim(phone);

        if (fullName.length() < 2 || fullName.length() > 100) errors.add("Enter your full name (2-100 characters).");
        if (!Validator.email(email)) errors.add("Enter a valid email address.");
        if (!Validator.strongPassword(password)) errors.add("Password must be at least 8 characters and contain a letter and a digit.");
        else if (!password.equals(confirm)) errors.add("The two passwords do not match.");
        if (role == Role.LEARNER && !Validator.omang(idNumber)) errors.add("Enter your 9-digit Omang number.");
        if (!phone.isEmpty() && !Validator.phone(phone)) errors.add("Enter a valid phone number.");
        if (!errors.isEmpty()) return errors;

        try (Connection c = DbPool.get()) {
            if (userDao.existsByEmail(c, email)) {
                errors.add("An account with this email already exists.");
                return errors;
            }
            User u = new User();
            u.setFullName(fullName);
            u.setEmail(email);
            u.setPasswordHash(PasswordUtil.hash(password));
            u.setRole(role);
            u.setIdNumber(role == Role.LEARNER ? idNumber : null);
            u.setPhone(phone.isEmpty() ? null : phone);
            userDao.insert(c, u);
            return errors;
        } catch (SQLException e) { throw new DataAccessException(e); }
    }
}
