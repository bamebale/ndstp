package bw.ndstp.service;

import bw.ndstp.dao.BookingDao;
import bw.ndstp.dao.DataAccessException;
import bw.ndstp.dao.SchoolDao;
import bw.ndstp.dao.SlotDao;
import bw.ndstp.dao.UserDao;
import bw.ndstp.model.BookingStatus;
import bw.ndstp.model.Role;
import bw.ndstp.util.DbPool;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

public class StatsService {
    private final UserDao userDao = new UserDao();
    private final SchoolDao schoolDao = new SchoolDao();
    private final SlotDao slotDao = new SlotDao();
    private final BookingDao bookingDao = new BookingDao();

    public Map<String, Integer> stats() {
        try (Connection c = DbPool.get()) {
            Map<String, Integer> m = new LinkedHashMap<>();
            int allSchools = schoolDao.count(c, false);
            int accredited = schoolDao.count(c, true);
            m.put("learners", userDao.countByRole(c, Role.LEARNER));
            m.put("managers", userDao.countByRole(c, Role.SCHOOL_MANAGER));
            m.put("schools", accredited);
            m.put("pendingSchools", allSchools - accredited);
            m.put("upcomingSlots", slotDao.countUpcoming(c));
            m.put("confirmed", bookingDao.countByStatus(c, BookingStatus.CONFIRMED));
            m.put("passed", bookingDao.countByStatus(c, BookingStatus.PASSED));
            m.put("failed", bookingDao.countByStatus(c, BookingStatus.FAILED));
            return m;
        } catch (SQLException e) { throw new DataAccessException(e); }
    }
}
