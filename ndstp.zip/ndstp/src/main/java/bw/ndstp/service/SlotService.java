package bw.ndstp.service;

import bw.ndstp.dao.DataAccessException;
import bw.ndstp.dao.SlotDao;
import bw.ndstp.model.TestSlot;
import bw.ndstp.model.TestType;
import bw.ndstp.util.DbPool;
import bw.ndstp.util.Validator;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class SlotService {
    private final SlotDao slotDao = new SlotDao();

    public List<TestSlot> upcoming(TestType type) {
        try (Connection c = DbPool.get()) {
            return slotDao.findUpcoming(c, type);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public List<TestSlot> listAll() {
        try (Connection c = DbPool.get()) {
            return slotDao.findAll(c);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public TestSlot find(int id) {
        try (Connection c = DbPool.get()) {
            return slotDao.findById(c, id);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    /** Admin creates a slot. Returns validation errors (empty on success). */
    public List<String> create(String type, String dateTime, String location, String capacity) {
        List<String> errors = new ArrayList<>();
        TestType testType = null;
        try { testType = TestType.valueOf(Validator.trim(type)); }
        catch (IllegalArgumentException e) { errors.add("Choose a test type."); }

        Timestamp when = null;
        try {
            LocalDateTime ldt = LocalDateTime.parse(Validator.trim(dateTime));
            if (ldt.isBefore(LocalDateTime.now())) errors.add("The date and time must be in the future.");
            else when = Timestamp.valueOf(ldt);
        } catch (DateTimeParseException e) { errors.add("Enter a valid date and time."); }

        location = Validator.trim(location);
        if (location.isEmpty() || location.length() > 100) errors.add("Enter the test centre location.");

        int cap = 0;
        try {
            cap = Integer.parseInt(Validator.trim(capacity));
            if (cap < 1 || cap > 500) errors.add("Capacity must be between 1 and 500.");
        } catch (NumberFormatException e) { errors.add("Capacity must be a number."); }

        if (!errors.isEmpty()) return errors;

        TestSlot slot = new TestSlot();
        slot.setTestType(testType);
        slot.setSlotDateTime(when);
        slot.setLocation(location);
        slot.setCapacity(cap);
        try (Connection c = DbPool.get()) {
            slotDao.insert(c, slot);
        } catch (SQLException e) {
            throw new DataAccessException(e);
        } catch (DataAccessException e) {
            if (e.getCause() instanceof SQLIntegrityConstraintViolationException) {
                errors.add("A slot for that test, time and location already exists.");
            } else throw e;
        }
        return errors;
    }
}
