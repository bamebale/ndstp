package bw.ndstp.service;

import bw.ndstp.dao.BookingDao;
import bw.ndstp.dao.DataAccessException;
import bw.ndstp.dao.SlotDao;
import bw.ndstp.model.Booking;
import bw.ndstp.model.BookingStatus;
import bw.ndstp.model.TestSlot;
import bw.ndstp.model.TestType;
import bw.ndstp.util.DbPool;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/** Booking rules: sequential tests, no double booking, 24h cancellation window. */
public class BookingService {
    private final SlotDao slotDao = new SlotDao();
    private final BookingDao bookingDao = new BookingDao();

    @FunctionalInterface
    private interface Work {
        void run(Connection c) throws BookingException;
    }

    /** Runs the work in one transaction; rolls back on any failure. */
    private void inTransaction(Work work) throws BookingException {
        try (Connection c = DbPool.get()) {
            c.setAutoCommit(false);
            try {
                work.run(c);
                c.commit();
            } catch (BookingException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    /** Why this learner cannot book this test type right now, or null if they can. */
    public String blockedReason(int learnerId, TestType type) {
        try (Connection c = DbPool.get()) {
            return blockedReason(c, learnerId, type);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    private String blockedReason(Connection c, int learnerId, TestType type) {
        TestType prev = type.previous();
        if (prev != null && !bookingDao.hasStatus(c, learnerId, prev, BookingStatus.PASSED)) {
            return "You must pass the " + prev.getLabel().toLowerCase() + " before booking the "
                    + type.getLabel().toLowerCase() + ".";
        }
        if (bookingDao.hasStatus(c, learnerId, type, BookingStatus.PASSED)) {
            return "You have already passed the " + type.getLabel().toLowerCase() + ".";
        }
        if (bookingDao.hasStatus(c, learnerId, type, BookingStatus.CONFIRMED)) {
            return "You already have a " + type.getLabel().toLowerCase()
                    + " booked. Cancel it first if you want a different date.";
        }
        return null;
    }

    public void book(int learnerId, int slotId) throws BookingException {
        inTransaction(c -> {
            TestSlot slot = slotDao.lockById(c, slotId);            // row lock: one booking at a time per slot
            if (slot == null) throw new BookingException("That slot no longer exists.");
            if (slot.isPast()) throw new BookingException("That slot has already passed.");
            if (slot.isFull()) throw new BookingException("Sorry, this slot is now full. Choose another date.");
            String reason = blockedReason(c, learnerId, slot.getTestType());
            if (reason != null) throw new BookingException(reason);
            bookingDao.insertOrReactivate(c, slotId, learnerId);
            slotDao.adjustBooked(c, slotId, 1);
        });
    }

    public void cancel(int learnerId, int bookingId) throws BookingException {
        inTransaction(c -> {
            Booking b = bookingDao.findById(c, bookingId);
            if (b == null || b.getLearnerId() != learnerId) throw new BookingException("Booking not found.");
            slotDao.lockById(c, b.getSlotId());
            b = bookingDao.findById(c, bookingId);                   // re-read under the lock
            if (b.getStatus() != BookingStatus.CONFIRMED) {
                throw new BookingException("Only confirmed bookings can be cancelled.");
            }
            if (!b.isCancellable()) {
                throw new BookingException("Bookings can only be cancelled up to "
                        + Booking.CANCEL_WINDOW_HOURS + " hours before the test.");
            }
            bookingDao.updateStatus(c, bookingId, BookingStatus.CANCELLED);
            slotDao.adjustBooked(c, b.getSlotId(), -1);
        });
    }

    /** Admin records the outcome of a test. */
    public void recordResult(int bookingId, BookingStatus result) throws BookingException {
        if (result != BookingStatus.PASSED && result != BookingStatus.FAILED) {
            throw new BookingException("Result must be PASSED or FAILED.");
        }
        inTransaction(c -> {
            Booking b = bookingDao.findById(c, bookingId);
            if (b == null) throw new BookingException("Booking not found.");
            slotDao.lockById(c, b.getSlotId());
            b = bookingDao.findById(c, bookingId);
            if (b.getStatus() != BookingStatus.CONFIRMED) {
                throw new BookingException("A result can only be recorded for a confirmed booking.");
            }
            bookingDao.updateStatus(c, bookingId, result);
        });
    }

    public List<Booking> listByLearner(int learnerId) {
        try (Connection c = DbPool.get()) {
            return bookingDao.findByLearner(c, learnerId);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public List<Booking> listBySlot(int slotId) {
        try (Connection c = DbPool.get()) {
            return bookingDao.findBySlot(c, slotId);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }
}
