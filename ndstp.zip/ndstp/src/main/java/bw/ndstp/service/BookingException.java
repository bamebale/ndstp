package bw.ndstp.service;

/** A business-rule failure whose message is safe to show to the user. */
public class BookingException extends Exception {
    public BookingException(String message) { super(message); }
}
