package bw.ndstp.dao;

import java.sql.SQLException;

/** Unchecked wrapper so servlets and services are not cluttered with SQLException. */
public class DataAccessException extends RuntimeException {
    public DataAccessException(SQLException cause) { super(cause.getMessage(), cause); }
}
