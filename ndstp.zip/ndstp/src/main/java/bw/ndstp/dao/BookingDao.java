package bw.ndstp.dao;

import bw.ndstp.model.Booking;
import bw.ndstp.model.BookingStatus;
import bw.ndstp.model.TestType;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookingDao {
    private static final String BASE =
            "SELECT b.booking_id, b.slot_id, b.learner_id, b.status, b.created_at, "
          + "s.test_type, s.slot_datetime, s.location, u.full_name, u.email "
          + "FROM booking b "
          + "JOIN test_slot s ON s.slot_id = b.slot_id "
          + "JOIN users u ON u.user_id = b.learner_id ";

    /** Creates the booking, or re-activates it if this learner previously cancelled the same slot. */
    public void insertOrReactivate(Connection c, int slotId, int learnerId) {
        try {
            int updated;
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE booking SET status = 'CONFIRMED' WHERE slot_id = ? AND learner_id = ?")) {
                ps.setInt(1, slotId);
                ps.setInt(2, learnerId);
                updated = ps.executeUpdate();
            }
            if (updated == 0) {
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO booking (slot_id, learner_id, status) VALUES (?, ?, 'CONFIRMED')")) {
                    ps.setInt(1, slotId);
                    ps.setInt(2, learnerId);
                    ps.executeUpdate();
                }
            }
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public void updateStatus(Connection c, int bookingId, BookingStatus status) {
        try (PreparedStatement ps = c.prepareStatement("UPDATE booking SET status = ? WHERE booking_id = ?")) {
            ps.setString(1, status.name());
            ps.setInt(2, bookingId);
            ps.executeUpdate();
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public Booking findById(Connection c, int id) {
        List<Booking> list = query(c, BASE + "WHERE b.booking_id = ?", id);
        return list.isEmpty() ? null : list.get(0);
    }

    public List<Booking> findByLearner(Connection c, int learnerId) {
        return query(c, BASE + "WHERE b.learner_id = ? ORDER BY s.slot_datetime DESC", learnerId);
    }

    public List<Booking> findBySlot(Connection c, int slotId) {
        return query(c, BASE + "WHERE b.slot_id = ? ORDER BY u.full_name", slotId);
    }

    /** Does this learner have a booking of the given test type in the given status? */
    public boolean hasStatus(Connection c, int learnerId, TestType type, BookingStatus status) {
        String sql = "SELECT COUNT(*) FROM booking b JOIN test_slot s ON s.slot_id = b.slot_id "
                + "WHERE b.learner_id = ? AND s.test_type = ? AND b.status = ?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, learnerId);
            ps.setString(2, type.name());
            ps.setString(3, status.name());
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public int countByStatus(Connection c, BookingStatus status) {
        try (PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM booking WHERE status = ?")) {
            ps.setString(1, status.name());
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    private List<Booking> query(Connection c, String sql, int param) {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, param);
            try (ResultSet rs = ps.executeQuery()) {
                List<Booking> list = new ArrayList<>();
                while (rs.next()) list.add(map(rs));
                return list;
            }
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    private Booking map(ResultSet rs) throws SQLException {
        Booking b = new Booking();
        b.setId(rs.getInt("booking_id"));
        b.setSlotId(rs.getInt("slot_id"));
        b.setLearnerId(rs.getInt("learner_id"));
        b.setStatus(BookingStatus.valueOf(rs.getString("status")));
        b.setCreatedAt(rs.getTimestamp("created_at"));
        b.setTestType(TestType.valueOf(rs.getString("test_type")));
        b.setSlotDateTime(rs.getTimestamp("slot_datetime"));
        b.setLocation(rs.getString("location"));
        b.setLearnerName(rs.getString("full_name"));
        b.setLearnerEmail(rs.getString("email"));
        return b;
    }
}
