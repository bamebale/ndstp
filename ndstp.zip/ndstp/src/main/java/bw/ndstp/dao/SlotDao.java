package bw.ndstp.dao;

import bw.ndstp.model.TestSlot;
import bw.ndstp.model.TestType;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SlotDao {
    private static final String COLS = "slot_id, test_type, slot_datetime, location, capacity, booked";

    public List<TestSlot> findUpcoming(Connection c, TestType type) {
        String sql = "SELECT " + COLS + " FROM test_slot WHERE test_type = ? AND slot_datetime > CURRENT_TIMESTAMP "
                + "ORDER BY slot_datetime";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, type.name());
            return list(ps);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public List<TestSlot> findAll(Connection c) {
        String sql = "SELECT " + COLS + " FROM test_slot ORDER BY slot_datetime DESC LIMIT 200";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            return list(ps);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public TestSlot findById(Connection c, int id) {
        return one(c, "SELECT " + COLS + " FROM test_slot WHERE slot_id = ?", id);
    }

    /** SELECT ... FOR UPDATE: serialises concurrent bookings of the same slot. Call inside a transaction. */
    public TestSlot lockById(Connection c, int id) {
        return one(c, "SELECT " + COLS + " FROM test_slot WHERE slot_id = ? FOR UPDATE", id);
    }

    public int insert(Connection c, TestSlot s) {
        String sql = "INSERT INTO test_slot (test_type, slot_datetime, location, capacity) VALUES (?,?,?,?)";
        try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, s.getTestType().name());
            ps.setTimestamp(2, s.getSlotDateTime());
            ps.setString(3, s.getLocation());
            ps.setInt(4, s.getCapacity());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public void adjustBooked(Connection c, int slotId, int delta) {
        try (PreparedStatement ps = c.prepareStatement("UPDATE test_slot SET booked = booked + ? WHERE slot_id = ?")) {
            ps.setInt(1, delta);
            ps.setInt(2, slotId);
            ps.executeUpdate();
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public int countUpcoming(Connection c) {
        try (PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM test_slot WHERE slot_datetime > CURRENT_TIMESTAMP");
             ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    private TestSlot one(Connection c, String sql, int id) {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    private List<TestSlot> list(PreparedStatement ps) throws SQLException {
        try (ResultSet rs = ps.executeQuery()) {
            List<TestSlot> list = new ArrayList<>();
            while (rs.next()) list.add(map(rs));
            return list;
        }
    }

    private TestSlot map(ResultSet rs) throws SQLException {
        TestSlot s = new TestSlot();
        s.setId(rs.getInt("slot_id"));
        s.setTestType(TestType.valueOf(rs.getString("test_type")));
        s.setSlotDateTime(rs.getTimestamp("slot_datetime"));
        s.setLocation(rs.getString("location"));
        s.setCapacity(rs.getInt("capacity"));
        s.setBooked(rs.getInt("booked"));
        return s;
    }
}
