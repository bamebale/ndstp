package bw.ndstp.dao;

import bw.ndstp.model.DrivingSchool;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SchoolDao {
    private static final String COLS =
            "school_id, manager_id, name, description, location, phone, email, fee_per_lesson, accredited";

    public int insert(Connection c, DrivingSchool s) {
        String sql = "INSERT INTO driving_school (manager_id, name, description, location, phone, email, fee_per_lesson) "
                + "VALUES (?,?,?,?,?,?,?)";
        try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, s.getManagerId());
            ps.setString(2, s.getName());
            ps.setString(3, s.getDescription());
            ps.setString(4, s.getLocation());
            ps.setString(5, s.getPhone());
            ps.setString(6, s.getEmail());
            ps.setBigDecimal(7, s.getFeePerLesson());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    /** Managers can only update their own school (WHERE manager_id = ?). */
    public void update(Connection c, DrivingSchool s) {
        String sql = "UPDATE driving_school SET name=?, description=?, location=?, phone=?, email=?, fee_per_lesson=? "
                + "WHERE manager_id=?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, s.getName());
            ps.setString(2, s.getDescription());
            ps.setString(3, s.getLocation());
            ps.setString(4, s.getPhone());
            ps.setString(5, s.getEmail());
            ps.setBigDecimal(6, s.getFeePerLesson());
            ps.setInt(7, s.getManagerId());
            ps.executeUpdate();
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public void setAccredited(Connection c, int schoolId, boolean accredited) {
        try (PreparedStatement ps = c.prepareStatement("UPDATE driving_school SET accredited=? WHERE school_id=?")) {
            ps.setBoolean(1, accredited);
            ps.setInt(2, schoolId);
            ps.executeUpdate();
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public DrivingSchool findByManager(Connection c, int managerId) {
        return one(c, "SELECT " + COLS + " FROM driving_school WHERE manager_id = ?", managerId);
    }

    public DrivingSchool findById(Connection c, int id) {
        return one(c, "SELECT " + COLS + " FROM driving_school WHERE school_id = ?", id);
    }

    public List<DrivingSchool> findAll(Connection c) {
        return search(c, null, null, null, false);
    }

    /** Dynamic filter: free text, exact location, maximum fee. All values are bound parameters. */
    public List<DrivingSchool> search(Connection c, String text, String location, BigDecimal maxFee,
                                      boolean accreditedOnly) {
        StringBuilder sql = new StringBuilder("SELECT " + COLS + " FROM driving_school WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (accreditedOnly) sql.append(" AND accredited = TRUE");
        if (text != null && !text.isBlank()) {
            sql.append(" AND (name LIKE ? OR description LIKE ?)");
            String like = "%" + text.trim() + "%";
            params.add(like);
            params.add(like);
        }
        if (location != null && !location.isBlank()) {
            sql.append(" AND location = ?");
            params.add(location.trim());
        }
        if (maxFee != null) {
            sql.append(" AND fee_per_lesson <= ?");
            params.add(maxFee);
        }
        sql.append(" ORDER BY name");
        try (PreparedStatement ps = c.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) ps.setObject(i + 1, params.get(i));
            try (ResultSet rs = ps.executeQuery()) {
                List<DrivingSchool> list = new ArrayList<>();
                while (rs.next()) list.add(map(rs));
                return list;
            }
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public List<String> accreditedLocations(Connection c) {
        String sql = "SELECT DISTINCT location FROM driving_school WHERE accredited = TRUE ORDER BY location";
        try (PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            List<String> list = new ArrayList<>();
            while (rs.next()) list.add(rs.getString(1));
            return list;
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public int count(Connection c, boolean accreditedOnly) {
        String sql = "SELECT COUNT(*) FROM driving_school" + (accreditedOnly ? " WHERE accredited = TRUE" : "");
        try (PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    private DrivingSchool one(Connection c, String sql, int id) {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    private DrivingSchool map(ResultSet rs) throws SQLException {
        DrivingSchool s = new DrivingSchool();
        s.setId(rs.getInt("school_id"));
        s.setManagerId(rs.getInt("manager_id"));
        s.setName(rs.getString("name"));
        s.setDescription(rs.getString("description"));
        s.setLocation(rs.getString("location"));
        s.setPhone(rs.getString("phone"));
        s.setEmail(rs.getString("email"));
        s.setFeePerLesson(rs.getBigDecimal("fee_per_lesson"));
        s.setAccredited(rs.getBoolean("accredited"));
        return s;
    }
}
