package bw.ndstp.dao;

import bw.ndstp.model.Role;
import bw.ndstp.model.User;

import java.sql.*;

public class UserDao {
    private static final String COLS = "user_id, full_name, email, password_hash, role, id_number, phone, created_at";

    public User findByEmail(Connection c, String email) {
        String sql = "SELECT " + COLS + " FROM users WHERE email = ?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email.toLowerCase());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public boolean existsByEmail(Connection c, String email) {
        return findByEmail(c, email) != null;
    }

    public boolean existsByRole(Connection c, Role role) {
        return countByRole(c, role) > 0;
    }

    public int countByRole(Connection c, Role role) {
        try (PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM users WHERE role = ?")) {
            ps.setString(1, role.name());
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    public int insert(Connection c, User u) {
        String sql = "INSERT INTO users (full_name, email, password_hash, role, id_number, phone) VALUES (?,?,?,?,?,?)";
        try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, u.getFullName());
            ps.setString(2, u.getEmail().toLowerCase());
            ps.setString(3, u.getPasswordHash());
            ps.setString(4, u.getRole().name());
            ps.setString(5, u.getIdNumber());
            ps.setString(6, u.getPhone());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        } catch (SQLException e) { throw new DataAccessException(e); }
    }

    private User map(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId(rs.getInt("user_id"));
        u.setFullName(rs.getString("full_name"));
        u.setEmail(rs.getString("email"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setRole(Role.valueOf(rs.getString("role")));
        u.setIdNumber(rs.getString("id_number"));
        u.setPhone(rs.getString("phone"));
        u.setCreatedAt(rs.getTimestamp("created_at"));
        return u;
    }
}
