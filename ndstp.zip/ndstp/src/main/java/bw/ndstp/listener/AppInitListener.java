package bw.ndstp.listener;

import bw.ndstp.dao.SchoolDao;
import bw.ndstp.dao.SlotDao;
import bw.ndstp.dao.UserDao;
import bw.ndstp.model.DrivingSchool;
import bw.ndstp.model.Role;
import bw.ndstp.model.TestSlot;
import bw.ndstp.model.TestType;
import bw.ndstp.model.User;
import bw.ndstp.util.DbPool;
import bw.ndstp.util.PasswordUtil;
import bw.ndstp.util.SchemaInitializer;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Timestamp;
import java.time.LocalDate;

/** On startup: creates tables, the default admin and (optionally) demo data. No manual SQL needed. */
@WebListener
public class AppInitListener implements ServletContextListener {
    private final UserDao userDao = new UserDao();
    private final SchoolDao schoolDao = new SchoolDao();
    private final SlotDao slotDao = new SlotDao();

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        try (Connection c = DbPool.get()) {
            SchemaInitializer.run(c);

            if (!userDao.existsByRole(c, Role.ADMIN)) {
                String email = DbPool.property("seed.admin.email");
                String password = DbPool.property("seed.admin.password");
                if (email != null && password != null) {
                    createUser(c, "DRTS Administrator", email, password, Role.ADMIN, null);
                    sce.getServletContext().log("Created default admin " + email);
                }
            }
            if ("true".equalsIgnoreCase(DbPool.property("seed.demo"))) {
                seedDemo(c);
                sce.getServletContext().log("Demo data ready (demo password: Demo@1234)");
            }
        } catch (Exception e) {
            sce.getServletContext().log("Startup initialisation failed: " + e.getMessage(), e);
        }
    }

    private void seedDemo(Connection c) {
        if (!userDao.existsByEmail(c, "learner@demo.bw")) {
            createUser(c, "Neo Demo Learner", "learner@demo.bw", "Demo@1234", Role.LEARNER, "123456789");
            String[][] schools = {
                {"manager1@demo.bw", "Kgale Driving Academy", "Gaborone", "250",
                 "Patient instructors, automatic and manual cars, theory classes every Saturday."},
                {"manager2@demo.bw", "Tati Road Masters", "Francistown", "220",
                 "Yard and road test preparation with a 95% first-time pass rate."},
                {"manager3@demo.bw", "Okavango Drivers Hub", "Maun", "280",
                 "Beginner-friendly lessons and refresher courses for returning drivers."}};
            for (String[] s : schools) {
                int id = createUser(c, s[1] + " Manager", s[0], "Demo@1234", Role.SCHOOL_MANAGER, null);
                DrivingSchool school = new DrivingSchool();
                school.setManagerId(id);
                school.setName(s[1]);
                school.setLocation(s[2]);
                school.setFeePerLesson(new BigDecimal(s[3]));
                school.setDescription(s[4]);
                school.setPhone("71234567");
                school.setEmail(s[0]);
                schoolDao.setAccredited(c, schoolDao.insert(c, school), true);
            }
        }
        if (slotDao.findAll(c).isEmpty()) {
            Object[][] slots = {   // type, days from today, hour, centre, capacity
                {TestType.THEORY, 3, 8, "Gaborone DRTS", 30}, {TestType.THEORY, 3, 13, "Gaborone DRTS", 30},
                {TestType.THEORY, 5, 9, "Francistown DRTS", 25}, {TestType.THEORY, 7, 9, "Maun DRTS", 20},
                {TestType.YARD, 6, 8, "Gaborone DRTS", 10}, {TestType.YARD, 8, 10, "Francistown DRTS", 10},
                {TestType.YARD, 10, 8, "Palapye DRTS", 8},
                {TestType.ROAD, 9, 8, "Gaborone DRTS", 6}, {TestType.ROAD, 12, 9, "Francistown DRTS", 6},
                {TestType.ROAD, 14, 8, "Maun DRTS", 5}};
            for (Object[] r : slots) {
                TestSlot s = new TestSlot();
                s.setTestType((TestType) r[0]);
                s.setSlotDateTime(Timestamp.valueOf(LocalDate.now().plusDays((int) r[1]).atTime((int) r[2], 0)));
                s.setLocation((String) r[3]);
                s.setCapacity((int) r[4]);
                slotDao.insert(c, s);
            }
        }
    }

    private int createUser(Connection c, String name, String email, String password, Role role, String idNumber) {
        User u = new User();
        u.setFullName(name);
        u.setEmail(email);
        u.setPasswordHash(PasswordUtil.hash(password));
        u.setRole(role);
        u.setIdNumber(idNumber);
        return userDao.insert(c, u);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        DbPool.close();
    }
}
