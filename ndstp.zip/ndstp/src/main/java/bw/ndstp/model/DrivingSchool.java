package bw.ndstp.model;

import java.math.BigDecimal;

public class DrivingSchool {
    private int id;
    private int managerId;
    private String name;
    private String description;
    private String location;
    private String phone;
    private String email;
    private BigDecimal feePerLesson;
    private boolean accredited;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getManagerId() { return managerId; }
    public void setManagerId(int managerId) { this.managerId = managerId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public BigDecimal getFeePerLesson() { return feePerLesson; }
    public void setFeePerLesson(BigDecimal feePerLesson) { this.feePerLesson = feePerLesson; }
    public boolean isAccredited() { return accredited; }
    public void setAccredited(boolean accredited) { this.accredited = accredited; }
}
