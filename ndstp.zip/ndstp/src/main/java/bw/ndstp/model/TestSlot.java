package bw.ndstp.model;

import java.sql.Timestamp;

public class TestSlot {
    private int id;
    private TestType testType;
    private Timestamp slotDateTime;
    private String location;
    private int capacity;
    private int booked;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public TestType getTestType() { return testType; }
    public void setTestType(TestType testType) { this.testType = testType; }
    public Timestamp getSlotDateTime() { return slotDateTime; }
    public void setSlotDateTime(Timestamp slotDateTime) { this.slotDateTime = slotDateTime; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    public int getBooked() { return booked; }
    public void setBooked(int booked) { this.booked = booked; }

    public int getAvailable() { return capacity - booked; }
    public boolean isFull() { return booked >= capacity; }
    public boolean isPast() { return slotDateTime.getTime() < System.currentTimeMillis(); }
}
