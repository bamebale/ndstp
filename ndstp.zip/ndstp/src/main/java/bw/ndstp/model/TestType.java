package bw.ndstp.model;

/** The three sequential licence tests: THEORY -> YARD -> ROAD. */
public enum TestType {
    THEORY("Theory test"),
    YARD("Yard test"),
    ROAD("Road test");

    private final String label;

    TestType(String label) { this.label = label; }

    public String getLabel() { return label; }

    /** The test that must be passed first, or null for THEORY. */
    public TestType previous() { return ordinal() == 0 ? null : values()[ordinal() - 1]; }

    public static TestType parse(String s) {
        try { return valueOf(s.trim().toUpperCase()); }
        catch (Exception e) { return THEORY; }
    }
}
