package bw.ndstp.model;

public enum Role {
    LEARNER("/learner/bookings"),
    SCHOOL_MANAGER("/school/profile"),
    ADMIN("/admin/dashboard");

    private final String homePath;

    Role(String homePath) { this.homePath = homePath; }

    public String getHomePath() { return homePath; }
}
