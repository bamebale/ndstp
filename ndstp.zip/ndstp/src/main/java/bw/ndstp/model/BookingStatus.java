package bw.ndstp.model;

public enum BookingStatus { CONFIRMED, CANCELLED, PASSED, FAILED }
