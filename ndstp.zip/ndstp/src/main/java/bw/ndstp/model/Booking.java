package bw.ndstp.model;

import java.sql.Timestamp;

public class Booking {
    public static final long CANCEL_WINDOW_HOURS = 24;

    private int id;
    private int slotId;
    private int learnerId;
    private BookingStatus status;
    private Timestamp createdAt;
    // joined data (slot + learner)
    private TestType testType;
    private Timestamp slotDateTime;
    private String location;
    private String learnerName;
    private String learnerEmail;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getSlotId() { return slotId; }
    public void setSlotId(int slotId) { this.slotId = slotId; }
    public int getLearnerId() { return learnerId; }
    public void setLearnerId(int learnerId) { this.learnerId = learnerId; }
    public BookingStatus getStatus() { return status; }
    public void setStatus(BookingStatus status) { this.status = status; }
    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
    public TestType getTestType() { return testType; }
    public void setTestType(TestType testType) { this.testType = testType; }
    public Timestamp getSlotDateTime() { return slotDateTime; }
    public void setSlotDateTime(Timestamp slotDateTime) { this.slotDateTime = slotDateTime; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getLearnerName() { return learnerName; }
    public void setLearnerName(String learnerName) { this.learnerName = learnerName; }
    public String getLearnerEmail() { return learnerEmail; }
    public void setLearnerEmail(String learnerEmail) { this.learnerEmail = learnerEmail; }

    /** A confirmed booking can be cancelled until 24 hours before the test. */
    public boolean isCancellable() {
        return status == BookingStatus.CONFIRMED
                && slotDateTime.getTime() - System.currentTimeMillis() >= CANCEL_WINDOW_HOURS * 3_600_000L;
    }
}
