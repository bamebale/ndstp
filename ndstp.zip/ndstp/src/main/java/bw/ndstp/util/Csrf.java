package bw.ndstp.util;

import jakarta.servlet.http.HttpSession;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

/** Synchronizer-token CSRF protection helpers. */
public final class Csrf {
    public static final String ATTRIBUTE = "csrfToken";
    public static final String PARAMETER = "_csrf";
    private static final SecureRandom RANDOM = new SecureRandom();

    private Csrf() { }

    public static String token(HttpSession session) {
        String token = (String) session.getAttribute(ATTRIBUTE);
        if (token == null) {
            byte[] bytes = new byte[32];
            RANDOM.nextBytes(bytes);
            token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
            session.setAttribute(ATTRIBUTE, token);
        }
        return token;
    }

    public static boolean isValid(HttpSession session, String submitted) {
        if (session == null || submitted == null) return false;
        String expected = (String) session.getAttribute(ATTRIBUTE);
        return expected != null && MessageDigest.isEqual(
                expected.getBytes(StandardCharsets.UTF_8), submitted.getBytes(StandardCharsets.UTF_8));
    }
}
