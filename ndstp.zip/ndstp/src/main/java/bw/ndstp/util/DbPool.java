package bw.ndstp.util;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

/** HikariCP pool over an embedded H2 file database (override with db.url / NDSTP_DB_URL if needed). */
public final class DbPool {
    private static final Properties PROPS = new Properties();
    private static HikariDataSource dataSource;

    static {
        try (InputStream in = DbPool.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (in != null) PROPS.load(in);
        } catch (IOException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private DbPool() { }

    public static String property(String key) { return PROPS.getProperty(key); }

    private static String setting(String envName, String propKey, String fallback) {
        String env = System.getenv(envName);
        if (env != null && !env.isBlank()) return env;
        return PROPS.getProperty(propKey, fallback);
    }

    public static synchronized Connection get() throws SQLException {
        if (dataSource == null) {
            String home = System.getProperty("user.home").replace('\\', '/');
            HikariConfig cfg = new HikariConfig();
            cfg.setDriverClassName(setting("NDSTP_DB_DRIVER", "db.driver", "org.h2.Driver"));
            cfg.setJdbcUrl(setting("NDSTP_DB_URL", "db.url", "jdbc:h2:file:" + home + "/ndstp-data/ndstp"));
            cfg.setUsername(setting("NDSTP_DB_USER", "db.user", "sa"));
            cfg.setPassword(setting("NDSTP_DB_PASSWORD", "db.password", ""));
            cfg.setMaximumPoolSize(Integer.parseInt(PROPS.getProperty("db.poolSize", "10")));
            cfg.setPoolName("ndstp-pool");
            dataSource = new HikariDataSource(cfg);
        }
        return dataSource.getConnection();
    }

    public static synchronized void close() {
        if (dataSource != null) {
            dataSource.close();
            dataSource = null;
        }
    }
}
