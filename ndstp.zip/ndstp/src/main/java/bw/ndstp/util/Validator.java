package bw.ndstp.util;

import java.util.regex.Pattern;

public final class Validator {
    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    private Validator() { }

    public static String trim(String s) { return s == null ? "" : s.trim(); }

    public static boolean blank(String s) { return s == null || s.isBlank(); }

    public static boolean email(String s) { return s != null && s.length() <= 120 && EMAIL.matcher(s).matches(); }

    /** Botswana national ID (Omang) is 9 digits. */
    public static boolean omang(String s) { return s != null && s.matches("\\d{9}"); }

    public static boolean phone(String s) { return s != null && s.matches("[+0-9 ]{7,15}"); }

    /** At least 8 characters with a letter and a digit. */
    public static boolean strongPassword(String s) {
        return s != null && s.length() >= 8 && s.length() <= 72
                && s.matches(".*[A-Za-z].*") && s.matches(".*\\d.*");
    }
}
