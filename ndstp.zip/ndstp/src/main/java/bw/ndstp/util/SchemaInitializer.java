package bw.ndstp.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.stream.Collectors;

/** Creates the tables from /schema.sql on startup (every statement is CREATE ... IF NOT EXISTS). */
public final class SchemaInitializer {
    private SchemaInitializer() { }

    public static void run(Connection c) throws SQLException, IOException {
        try (InputStream in = SchemaInitializer.class.getResourceAsStream("/schema.sql")) {
            if (in == null) throw new IOException("schema.sql not found on the classpath");
            String script = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)).lines()
                    .filter(line -> !line.trim().startsWith("--"))
                    .collect(Collectors.joining("\n"));
            try (Statement st = c.createStatement()) {
                for (String sql : script.split(";")) {
                    if (!sql.isBlank()) st.execute(sql);
                }
            }
        }
    }
}
