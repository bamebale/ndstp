package bw.ndstp.util;

import bw.ndstp.model.TestType;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UtilTest {
    @Test
    void passwordHashVerifies() {
        String hash = PasswordUtil.hash("Secret123");
        assertTrue(PasswordUtil.verify("Secret123", hash));
        assertFalse(PasswordUtil.verify("wrong", hash));
    }

    @Test
    void validatorRules() {
        assertTrue(Validator.email("a@b.co"));
        assertFalse(Validator.email("not-an-email"));
        assertTrue(Validator.omang("123456789"));
        assertFalse(Validator.omang("12345"));
        assertTrue(Validator.strongPassword("abcdefg1"));
        assertFalse(Validator.strongPassword("short1"));
        assertFalse(Validator.strongPassword("noDigitsHere"));
    }

    @Test
    void testSequenceIsEnforcedByEnumOrder() {
        assertNull(TestType.THEORY.previous());
        assertEquals(TestType.THEORY, TestType.YARD.previous());
        assertEquals(TestType.YARD, TestType.ROAD.previous());
    }
}
