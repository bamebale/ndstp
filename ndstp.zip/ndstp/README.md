# NDSTP - National Driving School & Testing Portal

Jakarta EE 10 (Servlet 6 + JSP/JSTL) on Tomcat 10.1, embedded H2 database (swappable for MySQL), Maven, Java 17.

## Run it in IntelliJ IDEA
No database to install: the app uses an embedded H2 database and creates its own tables and sample data on first start.
1. File > Open > select `pom.xml` > Open as Project. Wait for Maven to import.
2. Run > Edit Configurations > + > **Tomcat Server > Local**. Pick your Tomcat **10.1.x** folder.
   Deployment tab > + > Artifact > `ndstp:war exploded`. Set Application context to `/`.
3. Start it and open http://localhost:8080/

Data is stored in `<your home folder>/ndstp-data`. To reset everything, stop Tomcat and delete that folder.

## Accounts (created on first start by AppInitListener)
| Role | Email | Password |
|---|---|---|
| Admin | admin@ndstp.bw | Admin@12345 |
| Learner | learner@demo.bw | Demo@1234 |
| School manager | manager1@demo.bw | Demo@1234 |

Set `seed.demo=false` and change the admin password before any real deployment.

## Layout
```
controller/  Servlets (thin: read request, call service, forward to JSP)
service/     Business rules: sequential tests, transactions, validation
dao/         JDBC + SQL only (PreparedStatements everywhere)
model/       Plain classes and enums
filter/      CsrfFilter (all POSTs) and AccessFilter (RBAC by URL prefix)
listener/    AppInitListener (seeds admin and demo data)
util/        DbPool (HikariCP), PasswordUtil (BCrypt), Csrf, Validator
webapp/WEB-INF/views/  JSP + JSTL pages (not reachable by direct URL)
```

## Rules implemented
- Roles: LEARNER, SCHOOL_MANAGER, ADMIN. `/learner/*`, `/school/*`, `/admin/*` are blocked for other roles.
- Booking runs in a transaction with `SELECT ... FOR UPDATE` on the slot, plus `CHECK (booked <= capacity)` in the DB (schema is in `src/main/resources/schema.sql`).
- Theory must be PASSED before yard, yard before road. Admin records results per slot.
- A learner cannot hold two confirmed bookings of the same test type. Cancel allowed until 24h before.
- Driving schools appear publicly only after an admin accredits them.
